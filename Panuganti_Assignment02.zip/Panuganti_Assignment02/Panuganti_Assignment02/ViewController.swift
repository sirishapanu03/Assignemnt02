//
//  ViewController.swift
//  Panuganti_Assignment02
//
//  Created by Sirisha Panuganti on 9/12/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: Any) {
        
        var name = nameOutlet.text!
        var bill = Double(billAmountOutlet.text!) ?? 0
        var tipPercentage = Double(tipPercentageOutlet.text!) ?? 0
        
        var tipAmt :Double = (tipPercentage * bill)/100
        var totalBill = bill + tipAmt
        
        nameLabel.text! = "Name: \(name)"
        billAmountLabel.text! = "Bill Amount: $\(bill)"
        tipAmountLabel.text! = "Tip Amount: $\(String(format: "%.2f",tipAmt))"
        totalAmountLabel.text! = "Total Amount: $\(String(format: "%.2f",totalBill))"
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        nameLabel.text! = ""
        billAmountLabel.text! = ""
        tipAmountLabel.text! = ""
        totalAmountLabel.text! = ""
        
        nameOutlet.text! = ""
        billAmountOutlet.text! = ""
        tipPercentageOutlet.text! = ""
    }
}

