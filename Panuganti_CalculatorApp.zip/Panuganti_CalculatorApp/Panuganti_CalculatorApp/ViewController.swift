//
//  ViewController.swift
//  Panuganti_CalculatorApp
//
//  Created by Sirisha Panuganti on 9/24/23.
//

import UIKit

class ViewController: UIViewController {

      var num1: Double = 0.0
       var num2: Double = 0.0
       var myOutput: Int = 0
       var myOperator = ""
    
    @IBOutlet weak var resultOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func acClicked(_ sender: UIButton) {
        clearOutlet();
    }
    
    func clearOutlet(){
        resultOutlet.text = ""
        myOperator = ""
        num1 = 0
        num2 = 0.0
    }

  
    @IBAction func clearClicked(_ sender: UIButton) {
        var val = String(resultOutlet.text!)
        if(!val.isEmpty){
            val.removeLast()
        }
        resultOutlet.text! = val;
    }
    @IBAction func swapSign(_ sender: UIButton) {
        if let currentNum = Double(resultOutlet.text!){
                    let numAfterSwap = -currentNum
                    resultOutlet.text = String(numAfterSwap)
                }
    }
    
    @IBAction func division(_ sender: UIButton) {
        myOperator = "÷"
        num1 = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = ""
    }
    
    
    @IBAction func seven(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "7"

    }
    @IBAction func eight(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "8"
    }
    
    @IBAction func nine(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "9"
    }
    
    @IBAction func multiply(_ sender: UIButton) {
        myOperator = "*"
        num1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    
    @IBAction func four(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "4"
    }
    
    
    @IBAction func five(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "5"
    }
    
    
    @IBAction func six(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "6"
    }
    
    @IBAction func subtract(_ sender: UIButton) {
        myOperator = "-"
        num1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func three(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "3"
    }
    
    @IBAction func two(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "2"
    }
    
    @IBAction func one(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "1"
    }
    
    @IBAction func add(_ sender: UIButton) {
        myOperator = "+"
        num1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func zero(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "0"
    }
    
    @IBAction func decimal(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "."
    }
    
    @IBAction func percent(_ sender: UIButton) {
        myOperator = "%"
        num1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func equal(_ sender: Any) {
        num2 = Double(resultOutlet.text!)!
               
               switch myOperator{
               case "+" :
                   let addOutput = num1 + num2
                   if(addOutput != Double(Int(addOutput))){
                       resultOutlet.text = String(addOutput)
                   }else{
                       resultOutlet.text = String(Int(addOutput))
                   }
               case "-" :
                   myOutput = Int(num1 - num2)
                   resultOutlet.text = String(Int(exactly: myOutput)!)
               case "*" :
                   myOutput = Int(num1 * num2)
                   resultOutlet.text = String(myOutput)
               case "÷" :
                   if num2 == 0 {
                       resultOutlet.text = "Not a number"
                   }
                   else {
                       let result1 = num1/num2
                       resultOutlet.text = String(format: "%.5f", result1)
                   }
               case "%" :
                   let rem = num1.truncatingRemainder(dividingBy: num2)
                   resultOutlet.text = String(format: "%.1f", rem)

               default:
                   resultOutlet.text = "ERROR"
               }
    }
}

